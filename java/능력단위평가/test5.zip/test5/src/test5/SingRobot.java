package test5;

public class SingRobot extends Robot {
	void sing() {
		//3. "노래를 합니다." 를 출력한다.
		//(	업무 분석가가 분석한 요구사항에 대해 정의된 검증 기준과 절차에 따라서 요구사항을 확인할 수 있다.10)
		
		System.out.println("노래를 합니다.");
	}
}
