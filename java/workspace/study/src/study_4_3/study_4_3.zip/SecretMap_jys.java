package study_4_3;

public class SecretMap_jys {

	public static void main(String[] args) {
		SecretMap sm = new SecretMap();
		
		sm.inner();
		System.out.println();
		sm.decode();
	}

}
