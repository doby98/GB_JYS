package study_4_3;

public class Balance_jys {

	public static void main(String[] args) {
		Balance_mky bb = new Balance_mky();
		
		bb.inner();
//		bb.test();
		
	}

}
